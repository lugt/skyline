<html>
  <controls>
    <control controlID="1" controlTypeID="com.balsamiq.mockups::BrowserWindow" x="111" y="7" w="1206" h="756" measuredW="450" measuredH="400" zOrder="0" locked="false" isInGroup="-1">
      <controlProperties>
        <markup>true</markup>
        <text>A%20Web%20Page%0Ahttp%3A//</text>
      </controlProperties>
    </control>
    <control controlID="3" controlTypeID="com.balsamiq.mockups::Button" x="413" y="337" w="77" h="43" measuredW="48" measuredH="27" zOrder="1" locked="false" isInGroup="-1">
      <controlProperties>
        <text>%u4F60%u597D</text>
      </controlProperties>
    </control>
    <control controlID="4" controlTypeID="com.balsamiq.mockups::Arrow" x="613" y="310" w="453" h="10" measuredW="150" measuredH="100" zOrder="2" locked="false" isInGroup="-1">
      <controlProperties>
        <text/>
      </controlProperties>
    </control>
    <control controlID="5" controlTypeID="com.balsamiq.mockups::RoundButton" x="546" y="357" w="-1" h="-1" measuredW="32" measuredH="32" zOrder="3" locked="false" isInGroup="-1">
      <controlProperties>
        <text/>
      </controlProperties>
    </control>
    <control controlID="6" controlTypeID="com.balsamiq.mockups::BreadCrumbs" x="143" y="118" w="-1" h="-1" measuredW="211" measuredH="24" zOrder="4" locked="false" isInGroup="-1">
      <controlProperties>
        <text>Home%2C%20Products%2C%20Xyz%2C%20Features</text>
      </controlProperties>
    </control>
  </controls>
</html>