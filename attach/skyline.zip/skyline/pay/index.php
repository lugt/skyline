<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>充值中心</title>
</head>

<body>
<p>欢迎您通过Niimei Center 用户平台充值</p>
<p>支付遇到问题？<a href="http://niimei.com/matrix/">找点点！</a></p>
<p>充值金额(全场8.5折)：</p>
<p><input type="radio" name="count" value="10">
1000 S</input>&nbsp;
<input type="radio" name="count" value="10">
500 S</input>&nbsp;
<input type="radio" name="count" value="10">
200 S</input>&nbsp;
<input type="radio" name="count" value="10" checked="on">
100 S</input>&nbsp;
<input type="radio" name="count" value="10">
50 
</input>&nbsp;
<input type="radio" name="count" value="10">
10 积分</input>&nbsp;</p>
<p >所需积分&nbsp;<span id="cost" style="font-family:Verdana, Geneva, sans-serif;font-size:18px;">8.5  N</span> </p>
</body>
</html>