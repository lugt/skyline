Array
(
    [cast] => commu
    [cusId] => 1
)
---- breaker---- Array
(
    [imp] => Array
        (
            [name] => blob
            [type] => text/xml
            [tmp_name] => C:\Users\God\AppData\Local\Temp\phpDA29.tmp
            [error] => 0
            [size] => 13
        )

)