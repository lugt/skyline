<?php 

$addr_main = "http://niimei.com";

?>