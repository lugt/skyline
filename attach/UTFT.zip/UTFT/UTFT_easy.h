#include <UTFT.h>

void qingping();
void lcdZhunbei();
void xianshiLcd(String s);
int rdl();
int rdb();
int rdc();

int nline = 2;
// Declare which fonts we will be using
extern uint8_t SmallFont[];

// Declare an instance of the class
UTFT myGLCD(YYROBOT_TFT144,A2,A1,A5,A4,A3);   // Remember to change the model parameter to suit your display module!

void lcdZhunbei(){
  randomSeed(analogRead(0));  
// Setup the LCD
  myGLCD.InitLCD(PORTRAIT);
  myGLCD.setFont(SmallFont);
  // Set up the "Finished"-screen
  int e = rdb(), f =rdl(),g = rdb();
  int h = rdl(), j = rdl(), i = rdl();
  myGLCD.setContrast(0);
  myGLCD.fillScr(e,f,g);
  myGLCD.setColor(h,j,i);
  myGLCD.fillRoundRect(20, 20, 108, 108);
  myGLCD.setBackColor(h,j,i);
  myGLCD.setColor(constrain(e-10,0,255),constrain(f-10,0,255),constrain(g-10,0,255));
  myGLCD.print(F("TFT"), CENTER, 55);  
  delay(200);
}

void qingping(){
  int e = rdb(), f =rdl(),g = rdb();
  int h = rdl(), j = rdl(), i = rdl();
  myGLCD.setContrast(0);
  myGLCD.fillScr(e,f,g);
  myGLCD.setColor(h,j,i);
  myGLCD.fillRoundRect(20, 20, 108, 108);
  myGLCD.setBackColor(h,j,i);
  myGLCD.setColor(constrain(e-10,0,255),constrain(f-10,0,255),constrain(g-10,0,255));
  myGLCD.print(F("TFT"), CENTER, 55);    
}

void xianshiLcd(String s){
  int a = rdc();
  int b = rdb();
  int c = rdb();
  myGLCD.setColor(a,b,c);
  myGLCD.fillRoundRect(2,nline, 125,nline+14);
  myGLCD.setColor(rdl(),rdl(),rdl());
  myGLCD.setBackColor(a,b,c);
  myGLCD.print(s, CENTER, nline);  
  nline += 13;
  if(nline > 110){
    nline = 2;  
  }
}
int rdl(){
  return random(25)+220;
}
int rdc(){
  return random(75)+180;
}

int rdb(){
  return 50-random(50);
}

