<?php
//BANGPAI 1.0

// PURE SYStem For Loading the EXs.


//Now For Nothing

?>